-- QUERY NUMBER 01:
-- CHECK AND CREATE DATABASE
BEGIN TRY
    IF NOT EXISTS (SELECT * FROM SYS.DATABASES WHERE name = 'EmployeeManagementDB')
		BEGIN
		    CREATE DATABASE EmployeeManagementDB;
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE DATABASE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 02:
USE EmployeeManagementDB;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 03:
-- DEPARTMENTS TABLE
BEGIN TRY
    IF NOT EXISTS (SELECT * FROM EmployeeManagementDB.SYS.TABLES WHERE NAME = 'Departments')
		BEGIN
			CREATE TABLE Departments (
				DepartmentID VARCHAR(10) PRIMARY KEY,
				DepartmentName VARCHAR(100) NOT NULL,
				DepartmentLocation VARCHAR(100) NOT NULL,
				CreationDate DATE NOT NULL DEFAULT CURRENT_TIMESTAMP,
				CONSTRAINT Check_DepartmentID CHECK (DepartmentID LIKE 'DEPT[0-9][0-9][0-9][0-9][0-9][0-9]')
			);
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE TABLE ''DEPARTMENTS'': ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 04:
-- POSITIONS TABLE
BEGIN TRY
    IF NOT EXISTS (SELECT * FROM EmployeeManagementDB.SYS.TABLES WHERE NAME = 'Positions')
		BEGIN
			CREATE TABLE Positions (
				PositionID VARCHAR(10) PRIMARY KEY,
				PositionTitle VARCHAR(100) NOT NULL,
				DepartmentID VARCHAR(10) FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID),
				MinSalary MONEY DEFAULT NULL,
				MaxSalary MONEY DEFAULT NULL,
				JobDescription VARCHAR(100) DEFAULT NULL,
				CONSTRAINT Check_PositionID CHECK (PositionID LIKE 'POST[0-9][0-9][0-9][0-9][0-9][0-9]')
			);
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE TABLE ''POSITIONS'': ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 05:
-- EMPLOYEES TABLE
BEGIN TRY
    IF NOT EXISTS (SELECT * FROM EmployeeManagementDB.SYS.TABLES WHERE NAME = 'Employees')
		BEGIN
			CREATE TABLE Employees (
				EmployeeID VARCHAR(9) PRIMARY KEY,
				FirstName VARCHAR(50) NOT NULL,
				LastName VARCHAR(50) NOT NULL,
				Email VARCHAR(100) NULL,
				PhoneNumber BIGINT NULL,
				HireDate DATE NOT NULL,
				BaseSalary MONEY NOT NULL,
				Bonus MONEY NOT NULL,
				AnnualCompensation AS (BaseSalary + Bonus) * 12,
				PayDate DATE NOT NULL,
				DepartmentID VARCHAR(10) FOREIGN KEY (DepartmentID) REFERENCES Departments(DepartmentID),
				PositionID VARCHAR(10) FOREIGN KEY (PositionID) REFERENCES Positions(PositionID),
				CONSTRAINT Check_EmployeeID CHECK (EmployeeID LIKE 'EMP[0-9][0-9][0-9][0-9][0-9][0-9]'),
				CONSTRAINT Check_PhoneNumber CHECK (PhoneNumber LIKE '[0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]'),
				CONSTRAINT Check_Email CHECK (Email LIKE '%@%.%')
			);
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE TABLE ''EMPLOYEES'': ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 06:
-- PERFORMANCE REVIEW TABLE
BEGIN TRY
    IF NOT EXISTS (SELECT * FROM EmployeeManagementDB.SYS.TABLES WHERE NAME = 'PerformanceReview')
		BEGIN
			CREATE TABLE PerformanceReview (
				ReviewID VARCHAR(9) PRIMARY KEY,
				EmployeeID VARCHAR(9) FOREIGN KEY (EmployeeID) REFERENCES Employees(EmployeeID),
				ReviewDate DATE DEFAULT GETDATE(),
				Comments VARCHAR(255),
				Rating INT,
				CONSTRAINT Check_Rating CHECK (Rating LIKE '[0-9]'),
				CONSTRAINT Check_ReviewID CHECK (ReviewID LIKE 'REV[0-9][0-9][0-9][0-9][0-9][0-9]')
			);
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE TABLE ''PERFORMANCE REVIEW'': ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 07:
-- USER CREDENTIALS TABLE
BEGIN TRY
    IF NOT EXISTS (SELECT * FROM EmployeeManagementDB.SYS.TABLES WHERE NAME = 'Sign_Up')
		BEGIN
			CREATE TABLE Sign_Up (
				Username VARCHAR(20) PRIMARY KEY,
				Password VARCHAR(MAX)
			);
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE TABLE ''Sign_Up'': ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 08:
-- DATABASE VIEW
BEGIN TRY
	IF NOT EXISTS (SELECT * FROM EmployeeManagementDB.SYS.VIEWS WHERE OBJECT_ID = OBJECT_ID('EmployeeManagementView'))
		BEGIN
			EXEC('
				CREATE VIEW EmployeeManagementView AS
					SELECT
						EMP.EmployeeID, EMP.FirstName, EMP.LastName, EMP.Email, EMP.PhoneNumber, EMP.HireDate, EMP.BaseSalary, 
						EMP.Bonus, EMP.AnnualCompensation, EMP.PayDate, DP.DepartmentID, DP.DepartmentName, DP.DepartmentLocation,
						DP.CreationDate AS DepartmentCreationDate, POST.PositionID, POST.PositionTitle, POST.MinSalary, POST.MaxSalary,
						POST.JobDescription, REV.ReviewID, REV.ReviewDate, REV.Comments, REV.Rating
					FROM
						Employees AS EMP
					JOIN
						Departments AS DP ON EMP.DepartmentID = DP.DepartmentID
					JOIN
						Positions AS POST ON EMP.PositionID = POST.PositionID
					LEFT JOIN
						PerformanceReview AS REV ON EMP.EmployeeID = REV.EmployeeID;
			')
		END;
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE VIEW ''EmployeeManagementView'': ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 09:
-- INSERT DATA INTO THE DEPARTMENTS TABLE
BEGIN TRY
	INSERT INTO Departments (DepartmentID, DepartmentName, DepartmentLocation, CreationDate)
		VALUES
			('DEPT000001', 'HR', 'New York', '2023-01-01'),
			('DEPT000002', 'Finance', 'London', '2023-01-02'),
			('DEPT000003', 'IT', 'San Francisco', '2023-01-03'),
			('DEPT000004', 'Sales', 'Chicago', '2023-01-04'),
			('DEPT000005', 'Marketing', 'Los Angeles', '2023-01-05'),
			('DEPT000006', 'Legal', 'Houston', '2023-01-06'),
			('DEPT000007', 'R&D', 'Seattle', '2023-01-07'),
			('DEPT000008', 'Operations', 'Boston', '2023-01-08'),
			('DEPT000009', 'Customer Support', 'Miami', '2023-01-09'),
			('DEPT000010', 'Administration', 'Dallas', '2023-01-10'),
			('DEPT000011', 'Procurement', 'Denver', '2023-01-11'),
			('DEPT000012', 'Logistics', 'Phoenix', '2023-01-12'),
			('DEPT000013', 'Production', 'Philadelphia', '2023-01-13'),
			('DEPT000014', 'Engineering', 'San Diego', '2023-01-14'),
			('DEPT000015', 'Quality Assurance', 'Detroit', '2023-01-15'),
			('DEPT000016', 'Product Management', 'Minneapolis', '2023-01-16'),
			('DEPT000017', 'Compliance', 'Orlando', '2023-01-17'),
			('DEPT000018', 'Investor Relations', 'San Jose', '2023-01-18'),
			('DEPT000019', 'Public Relations', 'Charlotte', '2023-01-19'),
			('DEPT000020', 'Facilities', 'Columbus', '2023-01-20');
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE INSERTING RECORDS INTO THE ''DEPARTMENTS'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 10:
-- INSERT DATA INTO THE POSITIONS TABLE
BEGIN TRY
	INSERT INTO Positions (PositionID, PositionTitle, DepartmentID, MinSalary, MaxSalary, JobDescription)
		VALUES 
			('POST000001', 'HR Manager', 'DEPT000001', 50000, 70000, 'Manage HR department'),
			('POST000002', 'Accountant', 'DEPT000002', 60000, 80000, 'Handle financial records'),
			('POST000003', 'Software Engineer', 'DEPT000003', 80000, 120000, 'Develop software'),
			('POST000004', 'Sales Manager', 'DEPT000004', 70000, 90000, 'Manage sales team'),
			('POST000005', 'Marketing Specialist', 'DEPT000005', 60000, 85000, 'Develop marketing strategies'),
			('POST000006', 'Legal Advisor', 'DEPT000006', 90000, 110000, 'Provide legal advice'),
			('POST000007', 'Research Scientist', 'DEPT000007', 85000, 95000, 'Conduct research'),
			('POST000008', 'Operations Manager', 'DEPT000008', 75000, 95000, 'Oversee operations'),
			('POST000009', 'Customer Support Rep', 'DEPT000009', 40000, 60000, 'Support customers'),
			('POST000010', 'Admin Assistant', 'DEPT000010', 35000, 50000, 'Administrative support'),
			('POST000011', 'Procurement Officer', 'DEPT000011', 55000, 75000, 'Handle procurement'),
			('POST000012', 'Logistics Coordinator', 'DEPT000012', 50000, 70000, 'Coordinate logistics'),
			('POST000013', 'Production Supervisor', 'DEPT000013', 60000, 80000, 'Supervise production'),
			('POST000014', 'Engineer', 'DEPT000014', 70000, 100000, 'Engineering tasks'),
			('POST000015', 'QA Analyst', 'DEPT000015', 60000, 85000, 'Quality assurance'),
			('POST000016', 'Product Manager', 'DEPT000016', 90000, 120000, 'Manage products'),
			('POST000017', 'Compliance Officer', 'DEPT000017', 65000, 85000, 'Ensure compliance'),
			('POST000018', 'IR Specialist', 'DEPT000018', 80000, 100000, 'Investor relations'),
			('POST000019', 'PR Manager', 'DEPT000019', 75000, 95000, 'Public relations'),
			('POST000020', 'Facilities Manager', 'DEPT000020', 60000, 80000, 'Manage facilities');
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE INSERTING RECORDS INTO THE ''POSITIONS'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 11:
-- INSERT DATA INTO THE EMPLOYEES TABLE
BEGIN TRY
	INSERT INTO Employees (EmployeeID, FirstName, LastName, Email, PhoneNumber, HireDate, BaseSalary, Bonus, PayDate, DepartmentID, PositionID)
		VALUES
			('EMP000001', 'John', 'Doe', 'john.doe@example.com', 1234567890, '2020-01-15', 50000, 5000, '2024-06-30', 'DEPT000001', 'POST000001'),
			('EMP000002', 'Jane', 'Smith', 'jane.smith@example.com', 2345678901, '2019-03-20', 60000, 6000, '2024-06-30', 'DEPT000002', 'POST000002'),
			('EMP000003', 'Robert', 'Brown', 'robert.brown@example.com', 3456789012, '2021-05-10', 55000, 5500, '2024-06-30', 'DEPT000003', 'POST000003'),
			('EMP000004', 'Emily', 'Davis', 'emily.davis@example.com', 4567890123, '2018-07-25', 70000, 7000, '2024-06-30', 'DEPT000004', 'POST000004'),
			('EMP000005', 'Michael', 'Wilson', 'michael.wilson@example.com', 5678901234, '2020-11-05', 50000, 4000, '2024-06-30', 'DEPT000004', 'POST000005'),
			('EMP000006', 'Sarah', 'Miller', 'sarah.miller@example.com', 6789012345, '2019-08-15', 62000, 6200, '2024-06-30', 'DEPT000006', 'POST000006'),
			('EMP000007', 'David', 'Martinez', 'david.martinez@example.com', 7890123456, '2022-03-18', 58000, 5800, '2024-06-30', 'DEPT000007', 'POST000007'),
			('EMP000008', 'Laura', 'Anderson', 'laura.anderson@example.com', 8901234567, '2018-12-22', 51000, 5100, '2024-06-30', 'DEPT000008', 'POST000008'),
			('EMP000009', 'James', 'Taylor', 'james.taylor@example.com', 9012345678, '2017-09-30', 56000, 5600, '2024-06-30', 'DEPT000009', 'POST000009'),
			('EMP000010', 'Jessica', 'Thomas', 'jessica.thomas@example.com', 1123456789, '2016-06-01', 53000, 5300, '2024-06-30', 'DEPT000010', 'POST000010'),
			('EMP000011', 'William', 'Jackson', 'william.jackson@example.com', 2234567890, '2021-11-11', 49000, 4900, '2024-06-30', 'DEPT000011', 'POST000011'),
			('EMP000012', 'Olivia', 'White', 'olivia.white@example.com', 3345678901, '2020-10-19', 61000, 6100, '2024-06-30', 'DEPT000012', 'POST000012'),
			('EMP000013', 'Joshua', 'Harris', 'joshua.harris@example.com', 4456789012, '2018-04-13', 54000, 5400, '2024-06-30', 'DEPT000013', 'POST000013'),
			('EMP000014', 'Sophia', 'Clark', 'sophia.clark@example.com', 5567890123, '2019-07-29', 58000, 5800, '2024-06-30', 'DEPT000014', 'POST000014'),
			('EMP000015', 'Daniel', 'Lewis', 'daniel.lewis@example.com', 6678901234, '2022-02-05', 50000, 5000, '2024-06-30', 'DEPT000015', 'POST000015'),
			('EMP000016', 'Ava', 'Robinson', 'ava.robinson@example.com', 7789012345, '2021-06-23', 62000, 6200, '2024-06-30', 'DEPT000016', 'POST000016'),
			('EMP000017', 'Matthew', 'Walker', 'matthew.walker@example.com', 8890123456, '2020-09-17', 57000, 5700, '2024-06-30', 'DEPT000017', 'POST000017'),
			('EMP000018', 'Mia', 'Hall', 'mia.hall@example.com', 9901234567, '2019-05-21', 59000, 5900, '2024-06-30', 'DEPT000018', 'POST000018'),
			('EMP000019', 'Christopher', 'Allen', 'christopher.allen@example.com', 1012345678, '2018-11-08', 52000, 5200, '2024-06-30', 'DEPT000019', 'POST000019'),
			('EMP000020', 'Isabella', 'Young', 'isabella.young@example.com', 1123456789, '2017-08-03', 60000, 6000, '2024-06-30', 'DEPT000020', 'POST000020');
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE INSERTING RECORDS INTO THE ''EMPLOYEES'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 12:
-- INSERT DATA INTO THE PERFORMANCE REVIEW TABLE
BEGIN TRY
	INSERT INTO PerformanceReview (ReviewID, EmployeeID, ReviewDate, Comments, Rating)
		VALUES 
			('REV000001', 'EMP000001', GETDATE(), 'Excellent performance.', 9),
			('REV000002', 'EMP000002', GETDATE(), 'Good performance.', 7),
			('REV000003', 'EMP000003', GETDATE(), 'Satisfactory performance.', 5),
			('REV000004', 'EMP000004', GETDATE(), 'Needs improvement.', 4),
			('REV000005', 'EMP000005', GETDATE(), 'Outstanding performance.', 1),
			('REV000006', 'EMP000006', GETDATE(), 'Meets expectations.', 6),
			('REV000007', 'EMP000007', GETDATE(), 'Below expectations.', 3),
			('REV000008', 'EMP000008', GETDATE(), 'Exceeds expectations.', 8),
			('REV000009', 'EMP000009', GETDATE(), 'Good teamwork.', 7),
			('REV000010', 'EMP000010', GETDATE(), 'Poor performance.', 2),
			('REV000011', 'EMP000011', GETDATE(), 'Excellent leadership.', 9),
			('REV000012', 'EMP000012', GETDATE(), 'Satisfactory work.', 5),
			('REV000013', 'EMP000013', GETDATE(), 'Room for growth.', 4),
			('REV000014', 'EMP000014', GETDATE(), 'Highly dependable.', 8),
			('REV000015', 'EMP000015', GETDATE(), 'Outstanding commitment.', 9),
			('REV000016', 'EMP000016', GETDATE(), 'Average performance.', 6),
			('REV000017', 'EMP000017', GETDATE(), 'Needs significant improvement.', 3),
			('REV000018', 'EMP000018', GETDATE(), 'Consistently good.', 7),
			('REV000019', 'EMP000019', GETDATE(), 'Excellent innovation.', 9),
			('REV000020', 'EMP000020', GETDATE(), 'Underperformed.', 2);
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE INSERTING RECORDS INTO THE ''PERFORMANCE REVIEW'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 13:
-- SHOW STORED DATA FROM THE DEPARTMENTS TABLE
BEGIN TRY
	SELECT * FROM Departments;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''DEPARTMENTS'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 14:
-- SHOW STORED DATA FROM THE POSITIONS TABLE
BEGIN TRY
	SELECT * FROM Positions;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''POSITIONS'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 15:
-- SHOW STORED DATA FROM THE EMPLOYEES TABLE
BEGIN TRY
	SELECT * FROM Employees;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''EMPLOYEES'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 16:
-- SHOW STORED DATA FROM THE PERFORMANCE REVIEWS TABLE
BEGIN TRY
	SELECT * FROM PerformanceReview;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''PERFORMANCE REVIEW'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 17:
-- SHOW STORED DATA FROM THE SIGN_UP TABLE
BEGIN TRY
	SELECT * FROM Sign_Up;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''SIGN-UP'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 18:
-- SHOW STORED DATA FROM THE EMPLOYEEMANAGEMENT VIEW
BEGIN TRY
	SELECT * FROM EmployeeManagementView;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''EMPLOYEEMANAGEMENTVIEW'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 19:
-- UPDATING THE EMPLOYEES TABLE IN ORDER TO UPDATE THE VIEW AS MENTIONED IN THE CEP
BEGIN TRY
    UPDATE Employees
	SET FirstName = 'Kamran', LastName = 'Khurshid', Email = 'kamran.khurshid@example.com'
	WHERE EmployeeID = 'EMP000002'
END TRY

BEGIN CATCH
    PRINT CONCAT('ERROR OCCURED WHILE CREATING THE DATABASE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029

-- QUERY NUMBER 20:
-- SHOW STORED DATA FROM THE EMPLOYEEMANAGEMENT VIEW
BEGIN TRY
	SELECT * FROM EmployeeManagementView;
END TRY

BEGIN CATCH
	PRINT CONCAT('ERROR OCCURED WHILE SELECTING RECORDS FROM THE ''EMPLOYEEMANAGEMENTVIEW'' TABLE: ', ERROR_MESSAGE());
	PRINT CONCAT('ERROR CODE: ', CAST(@@ERROR AS NVARCHAR(10)));
END CATCH;
GO
-- FA22-BESE-0003 - FA22-BESE-0007 - FA22-BESE-0029